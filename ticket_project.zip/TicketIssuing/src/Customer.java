import java.util.Scanner;

public class Customer {
	private String name;
	private String phone;
	private int time;
	private String location;
	//Ticket tick = new Ticket();
	public int restaurant_choice() {
		Scanner sc = new Scanner(System.in);
		List list = new List();
		
		list.print_res();
		int i = sc.nextInt();
		System.out.println("���õ� �Ĵ� : " + i);
		
		return i;
	}
	
	public int check_number(){
		int number = 4;
		
		return number;
	}
	public void delete_ticket(){
		
	}
	public int enter(){
		int flag = 1;
		
		return flag;
	}
}
	/*	
//		SearchingFilter temp;
        Scanner sc = new Scanner(System.in);
        
        while(true) {
            System.out.println("�Ĵ� ���� ȭ��");
            System.out.println("1. �Ĵ� 1");
            System.out.println("2. �Ĵ� 2");
            System.out.println("3. �Ĵ� 3");
            System.out.println("4. �Ĵ� 4");
            System.out.println("5. �Ĵ� 5");

            int i = sc.nextInt();

            switch (i) {
                case 1:
                    supplier.roomUpdate();
                    break;
                case 2:
                	//X
                    break;
                case 3:
                    enterSupplierPage();
                    break;
                case 4:
                    enterBoard();
                    break;
                case 5:
                    sc.close();
                    System_Exit();
            }

        }



	}

}*/
