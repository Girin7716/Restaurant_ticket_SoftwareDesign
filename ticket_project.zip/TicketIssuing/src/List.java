
public class List {
	
	private int total_num = 5;
	public Restaurants[] res = new Restaurants[5];
	
	public void set_res(){
		for(int i = 0 ; i < total_num; i++){
			res[i] = new Restaurants(i); 
		}
		
	}
	public Restaurants get_res(int i){
		
		return res[i]; 
	}
	public void print_res(){
		 System.out.println("�Ĵ� ���� ȭ��");
         System.out.println("1. �Ĵ� 1");
         System.out.println("2. �Ĵ� 2");
         System.out.println("3. �Ĵ� 3");
         System.out.println("4. �Ĵ� 4");
         System.out.println("5. �Ĵ� 5");
         System.out.println("�Է� >>");
	}
}
