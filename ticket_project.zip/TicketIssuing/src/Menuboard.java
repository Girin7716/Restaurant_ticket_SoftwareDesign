
public class Menuboard {

	 public Menu[] a= new Menu[5];   
	   int count;
	   public Menuboard(Menu[] a,int count){
	      this.a=a;
	      this.count=count;
	   }
	   
	   public void add_menu(String menuname,double price){
	      Menu k = new Menu(menuname, price);
	      a[count++] = k;
	   }
	   public void print_menu(){
	      for(int i=0;i<count;i++)
	         System.out.println(a[i].food_name +" : " +a[i].food_price + "��");
	   }

}
