
public class Menu {
	String food_name;
	double food_price;

	public Menu(String name,double price){
	      this.food_name=name;
	      this.food_price=price;
	   }
}
